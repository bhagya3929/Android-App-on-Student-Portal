package com.example.kustudentportal;


public class Counselling_data {
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getSemesterbranch() {
        return semesterbranch;
    }

    public void setSemesterbranch(String semesterbranch) {
        this.semesterbranch = semesterbranch;
    }

    public String getQuery() {
        return query;
    }

    public void setQuery(String query) {
        this.query = query;
    }

    public String id;
    public String name;
    public String email;
    public String semesterbranch;
    public String query;

    public Counselling_data()
    {

    }
    public Counselling_data(String id, String name, String email, String semesterbranch,String query) {
        this.id = id;
        this.name=name;
        this.email=email;
        this.semesterbranch=semesterbranch;
        this.query=query;
    }
}
