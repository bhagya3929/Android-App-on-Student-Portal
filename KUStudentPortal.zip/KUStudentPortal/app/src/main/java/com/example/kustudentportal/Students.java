package com.example.kustudentportal;

public class Students {
    public String id;

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }

    public String getPhone() {
        return phone;
    }

    public String getSchoolname() {
        return schoolname;
    }

    public String getBranchname() {
        return branchname;
    }

    public String getSemestername() {
        return semestername;
    }

    public String getRoll() {
        return roll;
    }

    public String name;
    public String email;
    public String phone;



    public String schoolname;


    public void setAttendance(String attendance) {
        this.attendance = attendance;
    }

    public String getAttendance() {
        return attendance;
    }

    public String attendance;

    public void setId(String id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public void setSchoolname(String schoolname) {
        this.schoolname = schoolname;
    }

    public void setBranchname(String branchname) {
        this.branchname = branchname;
    }

    public void setSemestername(String semestername) {
        this.semestername = semestername;
    }

    public void setRoll(String roll) {
        this.roll = roll;
    }

    public String branchname;
    public String semestername;
    public String roll;
    public Students()
    {

    }
    public Students(String id, String name, String email, String phone, String schoolname, String branchname, String semestername, String roll,String attendance) {
        this.id = id;
        this.name=name;
        this.email=email;
        this.phone=phone;
        this.schoolname=schoolname;
        this.branchname=branchname;
        this.semestername=semestername;
        this.roll=roll;
        this.attendance = attendance;
    }
}
