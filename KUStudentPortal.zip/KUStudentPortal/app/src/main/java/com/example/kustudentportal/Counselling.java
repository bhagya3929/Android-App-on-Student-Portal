package com.example.kustudentportal;

import android.os.Bundle;
import android.text.TextUtils;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
public class Counselling extends AppCompatActivity {
    private FirebaseAuth mAuth;
    DatabaseReference databaseReference;
    EditText editTextName,editTextEmail,editTextAddress,editTextQuery;
    Button buttonSend;
    ProgressBar progressBar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_counselling);
        mAuth = FirebaseAuth.getInstance();
        databaseReference = FirebaseDatabase.getInstance().getReference("feedback");

        Toolbar toolbar=findViewById(R.id.toolbar);
        progressBar=(ProgressBar)findViewById(R.id.progressbar);
        editTextName=findViewById(R.id.name);
        editTextEmail=findViewById(R.id.email);
        editTextAddress=findViewById(R.id.address);
        editTextQuery=findViewById(R.id.query);
        buttonSend=(Button)findViewById(R.id.button11);
        buttonSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                addFeedback();
            }
        });
        setSupportActionBar(toolbar);
    }
    private void addFeedback()
    {

        String name = editTextName.getText().toString().trim();
        String email = editTextEmail.getText().toString().trim();
        String semesterbranch = editTextAddress.getText().toString().trim();
        String query = editTextQuery.getText().toString().trim();

        if (TextUtils.isEmpty(name))
        {
            editTextName.setError("Name required");
            editTextName.requestFocus();
            return;
        }
        else if (TextUtils.isEmpty(email))
        {
            editTextEmail.setError("Email required");
            editTextEmail.requestFocus();
            return;
        }
        else if (!Patterns.EMAIL_ADDRESS.matcher(email).matches())
        {
            editTextEmail.setError("PLease enter a valid email");
            editTextEmail.requestFocus();
            return;
        }
        else if(TextUtils.isEmpty(semesterbranch))
        {
            editTextAddress.setError("Address required");
            editTextAddress.requestFocus();
            return;
        }
        else if(TextUtils.isEmpty(query))
        {
            editTextQuery.setError("Query required");
            editTextQuery.requestFocus();
            return;
        }
        else {
            progressBar.setVisibility(View.VISIBLE);
            String id = databaseReference.push().getKey();

            Counselling_data feedback1 = new Counselling_data(id,name,email,semesterbranch,query);

            databaseReference.child(id).setValue(feedback1);

            progressBar.setVisibility(View.GONE);
            Toast.makeText(this,"Query sent", Toast.LENGTH_LONG).show();
            editTextName.setText(null);
            editTextEmail.setText(null);
            editTextAddress.setText(null);
            editTextQuery.setText(null);
        }


    }
}