package com.example.kustudentportal;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

public class Student_profile extends AppCompatActivity {
    Button buttonattendance,buttonsemresults,buttoncounselling,buttonfeedback,buttonachievements,buttontraining,buttonlogout;
    private FirebaseAuth mAuth;
    TextView textView24;
    private FirebaseDatabase firebaseDatabase;
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finishAffinity();
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_profile);
        buttonattendance=(Button)findViewById(R.id.button12);
        buttonfeedback=(Button)findViewById(R.id.button22);
        buttonsemresults=(Button)findViewById(R.id.button36);
        buttoncounselling=(Button)findViewById(R.id.button37);
        buttonachievements=(Button)findViewById(R.id.button38);
        buttontraining=(Button)findViewById(R.id.button39);
        buttonlogout=(Button)findViewById(R.id.button40);

        buttonattendance.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openAttendance();
            }
        });
        buttonsemresults.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openSemresult();
            }
        });
        buttoncounselling.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openCounselling();
            }
        });
        buttonfeedback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openRenovation();
            }
        });
        buttonachievements.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openAchievements();
            }
        });
        buttontraining.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openTraining();
            }
        });
        buttonlogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                logout();
            }
        });
        textView24=(TextView)findViewById(R.id.textView24);
        mAuth = FirebaseAuth.getInstance();
        firebaseDatabase= FirebaseDatabase.getInstance();
        DatabaseReference databaseReference = firebaseDatabase.getReference("Students").child(FirebaseAuth.getInstance().getCurrentUser().getUid());
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                Students student1=dataSnapshot.getValue(Students.class);
                textView24.setText("Hi "+student1.getName());
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(Student_profile.this,databaseError.getCode(), Toast.LENGTH_SHORT).show();
            }
        });
        Toolbar toolbar=findViewById(R.id.toolbar);

        setSupportActionBar(toolbar);
    }
    private void logout()
    {
        mAuth.signOut();
        finish();
        Intent logoutUser=new Intent(this,MainActivity.class);
        logoutUser.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_CLEAR_TASK|Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(logoutUser);
    }
    public void openAttendance()
    {
        Intent intent= new Intent(this, Attendance.class);
        startActivity(intent);
    }
    public void openSemresult()
    {
        /*Intent intent= new Intent(this, SemesterResult.class);
        startActivity(intent);*/
    }
    public void openRenovation()
    {
        /*Intent intent= new Intent(this, Feedback.class);
        startActivity(intent);*/
    }
    public void openCounselling()
    {
        Intent intent= new Intent(this, Counselling.class);
        startActivity(intent);
    }
    public void openAchievements()
    {
        /*Intent intent= new Intent(this, Achievements.class);
        startActivity(intent);*/
    }
    public void openTraining()
    {
        /*Intent intent= new Intent(this, Trainings.class);
        startActivity(intent);*/
    }
}