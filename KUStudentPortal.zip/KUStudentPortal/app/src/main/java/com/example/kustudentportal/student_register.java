package com.example.kustudentportal;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Patterns;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthUserCollisionException;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.Random;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
public class student_register extends AppCompatActivity {
    Button buttonAdd;
    EditText editTextName,editTextEmail,editTextPhone,editTextRoll,editTextPassword,editTextConfirm;
    Spinner school,branch,semester;
    ProgressBar progressBar;
    DatabaseReference databaseReference;
    private FirebaseAuth mAuth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_register);
        progressBar=(ProgressBar)findViewById(R.id.progressbar);
        editTextName=(EditText)findViewById(R.id.editText_name);
        editTextEmail=(EditText)findViewById(R.id.editText_email);
        editTextPhone=(EditText)findViewById(R.id.editText_phone);
        editTextRoll=(EditText)findViewById(R.id.editText_roll);
        editTextPassword=(EditText)findViewById(R.id.editText_password);
        editTextConfirm=(EditText)findViewById(R.id.editText_confirm);
        school=(Spinner)findViewById(R.id.spinner_School);
        branch=(Spinner) findViewById(R.id.spinner_branch);
        semester=(Spinner) findViewById(R.id.spinner_semester);
        buttonAdd=(Button) findViewById(R.id.button_addC);

        databaseReference = FirebaseDatabase.getInstance().getReference("Students");
        buttonAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AddCustomer();
            }
        });
        mAuth = FirebaseAuth.getInstance();

        final String schools[]={"Select School","B.Tech","M.Tech","BBA","MBA","BSc","MSc"};
        final String selectSchool[] = {"Select Branch"};
        final String selectSem[] = {"Select Semester"};
        final String BTechMTech[] = {"Select Branch","CSE","CE","ME","ECE","EEE"};
        final String BBAMBA[] = {"Select Branch","Retail & Marketing","Finance","HR"};
        final String BScMSc[] = {"Select Branch","Physics","Chemistry","Mathematics","Biology"};
        final String BtechSem[]={"Select Semester","Sem 1","Sem 2","Sem 3","Sem 4","Sem 5","Sem 6","Sem 7","Sem 8"};
        final String Bachelors[]={"Select Semester","Sem 1","Sem 2","Sem 3","Sem 4","Sem 5","Sem 6"};
        final String Masters[]={"Select Semester","Sem 1","Sem 2","Sem 3","Sem 4"};


        ArrayAdapter<String> adapter = new ArrayAdapter<String>(student_register.this,android.R.layout.simple_spinner_dropdown_item,schools);
        school.setAdapter(adapter);
        school.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                String itemSelect = schools[i];

                if (i == 0)
                {
                    ArrayAdapter<String> adapter1=new ArrayAdapter<String>(student_register.this,android.R.layout.simple_spinner_dropdown_item,selectSchool);
                    branch.setAdapter(adapter1);
                    ArrayAdapter<String> adapter11=new ArrayAdapter<String>(student_register.this,android.R.layout.simple_spinner_dropdown_item,selectSem);
                    semester.setAdapter(adapter11);
                }
                if (i == 1 || i == 2)
                {
                    ArrayAdapter<String> adapter2=new ArrayAdapter<String>(student_register.this,android.R.layout.simple_spinner_dropdown_item,BTechMTech);
                    branch.setAdapter(adapter2);
                    if(i==1)
                    {
                        ArrayAdapter<String> adapter22=new ArrayAdapter<String>(student_register.this,android.R.layout.simple_spinner_dropdown_item,BtechSem);
                        semester.setAdapter(adapter22);
                    }else {
                        ArrayAdapter<String> adapter222=new ArrayAdapter<String>(student_register.this,android.R.layout.simple_spinner_dropdown_item,Masters);
                        semester.setAdapter(adapter222);
                    }

                }
                if (i == 3 || i == 4 )
                {
                    ArrayAdapter<String> adapter3=new ArrayAdapter<String>(student_register.this,android.R.layout.simple_spinner_dropdown_item,BBAMBA);
                    branch.setAdapter(adapter3);
                    if(i==3)
                    {
                        ArrayAdapter<String> adapter33=new ArrayAdapter<String>(student_register.this,android.R.layout.simple_spinner_dropdown_item,Bachelors);
                        semester.setAdapter(adapter33);
                    }else {
                        ArrayAdapter<String> adapter333=new ArrayAdapter<String>(student_register.this,android.R.layout.simple_spinner_dropdown_item,Masters);
                        semester.setAdapter(adapter333);
                    }
                }
                if (i == 5 || i == 6)
                {
                    ArrayAdapter<String> adapter4=new ArrayAdapter<String>(student_register.this,android.R.layout.simple_spinner_dropdown_item,BScMSc);
                    branch.setAdapter(adapter4);
                    if(i==5)
                    {
                        ArrayAdapter<String> adapter44=new ArrayAdapter<String>(student_register.this,android.R.layout.simple_spinner_dropdown_item,Bachelors);
                        semester.setAdapter(adapter44);
                    }else {
                        ArrayAdapter<String> adapter444=new ArrayAdapter<String>(student_register.this,android.R.layout.simple_spinner_dropdown_item,Masters);
                        semester.setAdapter(adapter444);
                    }
                }

            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
    }
    private void AddCustomer()
    {
        final String name = editTextName.getText().toString().trim();
        final String email = editTextEmail.getText().toString().trim();
        final String phone = editTextPhone.getText().toString().trim();
        final String roll = editTextRoll.getText().toString().trim();
        String password = editTextPassword.getText().toString().trim();
        String confirm = editTextConfirm.getText().toString().trim();
        final String schoolname = school.getSelectedItem().toString();
        String cityvoid= "Select School";
        final String branchname = branch.getSelectedItem().toString();
        String areavoid= "Select Branch";
        final String semestername = semester.getSelectedItem().toString();
        String semestervoid= "Select Semester";

        final int atten1 = new Random().nextInt(95-65)+65;
        String attendance = Integer.toString(atten1);
        if (TextUtils.isEmpty(name))
        {
            editTextName.setError("Name required");
            editTextName.requestFocus();
            return;
        }
        else if (TextUtils.isEmpty(email))
        {
            editTextEmail.setError("Email required");
            editTextEmail.requestFocus();
            return;
        }
        else if (!Patterns.EMAIL_ADDRESS.matcher(email).matches())
        {
            editTextEmail.setError("PLease enter a valid email");
            editTextEmail.requestFocus();
            return;
        }
        else if (TextUtils.isEmpty(phone))
        {
            editTextPhone.setError("Phone no. required");
            editTextPhone.requestFocus();
            return;
        }
        else if (phone.length()!=10)
        {
            editTextPhone.setError("Please enter a valid 10 digit phone no");
            editTextPhone.requestFocus();
            return;
        }
        else if (schoolname==cityvoid)
        {
            Toast.makeText(this,"Please select a school",Toast.LENGTH_LONG).show();
        }
        else if (branchname==areavoid)
        {
            Toast.makeText(this,"Please select a branch",Toast.LENGTH_LONG).show();
        }
        else if (semestername==semestervoid)
        {
            Toast.makeText(this,"Please select a semester",Toast.LENGTH_LONG).show();
        }
        else if (TextUtils.isEmpty(roll))
        {
            editTextRoll.setError("Roll No. required");
            editTextRoll.requestFocus();
            return;
        }
        else if (TextUtils.isEmpty(password))
        {
            editTextPassword.setError("Password required");
            editTextPassword.requestFocus();
            return;
        }
        else if (password.length()<6)
        {
            editTextPassword.setError("Password length must be at least 6charcters");
            editTextPassword.requestFocus();
            return;
        }
        else if (TextUtils.isEmpty(confirm))
        {
            editTextConfirm.setError("Re-enter password");
            editTextConfirm.requestFocus();
            return;
        }
        else if (!password.equals(confirm))
        {
            editTextConfirm.setError("Passwords must match");
            editTextConfirm.requestFocus();
            return;
        }
        else{
            progressBar.setVisibility(View.VISIBLE);
            mAuth.createUserWithEmailAndPassword(email, password)
                    .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {

                            if (task.isSuccessful()) {

                                String id = FirebaseAuth.getInstance().getCurrentUser().getUid();
                                Students user = new Students(
                                        id,
                                        name,
                                        email,
                                        phone,
                                        schoolname,
                                        branchname,
                                        semestername,
                                        roll,
                                        attendance
                                );

                                databaseReference
                                        .child(FirebaseAuth.getInstance().getCurrentUser().getUid())
                                        .setValue(user).addOnCompleteListener(new OnCompleteListener<Void>() {
                                    @Override
                                    public void onComplete(@NonNull Task<Void> task) {
                                        if (task.isSuccessful()) {
                                            progressBar.setVisibility(View.GONE);
                                            finish();
                                            startActivity(new Intent(student_register.this,Student_profile.class));
                                        } else {
                                            progressBar.setVisibility(View.GONE);
                                            Toast.makeText(student_register.this,"Could not registered",Toast.LENGTH_LONG).show();

                                        }
                                    }
                                });

                            }
                            else {
                                progressBar.setVisibility(View.GONE);
                                if (task.getException() instanceof FirebaseAuthUserCollisionException)
                                {
                                    Toast.makeText(getApplicationContext(),"Email already registered",Toast.LENGTH_SHORT).show();
                                }
                                else
                                {
                                    Toast.makeText(getApplicationContext(),task.getException().getMessage(),Toast.LENGTH_SHORT).show();
                                }
                            }
                        }
                    });

        }
    }
}