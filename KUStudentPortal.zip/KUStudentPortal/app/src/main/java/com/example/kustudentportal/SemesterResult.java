package com.example.kustudentportal;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class SemesterResult extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_semester_result);
    }
}